#include <stdlib.h>

#include <stdio.h>

#include <unistd.h>

#include <errno.h>

#include <sys/wait.h>

#include <sys/types.h>


int main(void)

{

    pid_t pid;

	int i=0;
	for(i=0;i<2;i++)
	{
    do {

    pid= fork();

    } while ((pid == -1) && (errno == EAGAIN)&&(pid!=0));


    if (pid == -1) {

    perror("fork");

    } else if (pid == 0) {

    printf("Je suis le fils  pid = %d \n",getpid());

    } 
	}

    return EXIT_SUCCESS;

}



